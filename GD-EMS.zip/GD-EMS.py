import json
import threading
import time
import requests
from discord_webhook import *
from bs4 import BeautifulSoup

class Tracker:
    def __init__(self, delay, tracking, webhook):
        self.tracking = tracking
        self.webhook = webhook
        self.first_run = True
        self.delay = delay
        self.run = 0
        self.updates = []
    
    def send_webhook(self, date, status, location):
        webhook = DiscordWebhook(url=self.webhook)
        embed = DiscordEmbed(title=self.tracking, description='`New Activity!`', color=000000)
        embed.add_embed_field(name='Date', value=date, inline=False)
        embed.add_embed_field(name='Status', value=status, inline=False)
        embed.add_embed_field(name='Location', value=location, inline=False)
        embed.set_footer(text='GD-EMS Tracker | Toyu#0001', icon_url='https://cdn.discordapp.com/attachments/1052038814870274100/1054023301632098315/2.gif')
        embed.set_timestamp()
        embed.set_author(name='https://www.ems.post/', url='https://www.ems.post/', icon_url='https://posttrack.com/cdn/images/carriers/icons/0109-emspost.png')
        webhook.add_embed(embed)
        response = webhook.execute()
    
    def monitor(self):
        while True:
            self.run += 1
            if self.run < 6 or self.run % 500 == 0:
                print(f"[{self.tracking}] Monitor Alive! Run:"+str(self.run))
            
            try:
                r = requests.get('https://items.ems.post/api/publicTracking/track?language=EN&itemId='+self.tracking)
            except:
                print(f"[{self.tracking}] Error connecting to API...")
                time.sleep(5)
                continue
            
            if r.status_code == 200:
                soup = BeautifulSoup(r.text, 'html.parser')

                for update in soup.find_all('tr', class_='result-table-row'):
                    date = update.find_all('td')[0].text
                    status = update.find_all('td')[1].text
                    location = update.find_all('td')[2].text

                    if date == None:
                        date = "N/A"
                    if status == None:
                        status = "N/A"
                    if location == None:
                        location = "N/A"

                    if date not in self.updates:
                        self.updates.append(date)

                        if not self.first_run:
                            print(f"[{self.tracking}] New update found! Date:"+date+" Status:"+status+" Location:"+location)
                            self.send_webhook(date, status, location)
                
                if self.first_run:
                    print(f"[{self.tracking}] First run completed, now waiting for updates...")
                    self.first_run = False
                time.sleep(self.delay)
            else:
                print(f"[{self.tracking}] Bad Response from API... Got: "+str(r.status_code))
                time.sleep(5)
                continue
                

settings = json.load(open('settings.json'))

for tracking in settings['tracking_numbers']:
    threading.Thread(target=Tracker(settings['delay'], tracking, settings['webhook']).monitor).start()